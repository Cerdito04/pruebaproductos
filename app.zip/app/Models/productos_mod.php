<?php

namespace App\Models;

use CodeIgniter\Model;

class productos_mod extends Model
{
    protected $table      = 'productos';
    protected $primaryKey = 'ID';

    //protected $useAutoIncrement = true;

    protected $returnType     = 'array';

    protected $allowedFields = ['SKU', 'NOMBRE', 'DESCRIPCION', 'PRECIO'];

    public function subidaprod($sku,$nombre,$descripcion,$precio){

        // $variable="";
        // $variable.=(empty($sku)) "falta el sku <br>": "" ;
        // $variable.=(empty($nombre)) "falta el nombre <br>": "" ;
        // $variable.=(empty($descripcion)) "falta el descripcion <br>": "" ;
        // $variable.=(empty($precio)) "falta el precio <br>": "" ;

        // if(!empty($variable)) return $variable;
        $db=db_connect();
        $builder = $db->table('productos');
        
        $datos = array(
            'SKU' => $sku,
            'NOMBRE' => $nombre,
            'DESCRIPCION' => $descripcion,
            'PRECIO' => $precio
        );

        $builder->insert($datos);

        if ($db->insertID()>=1){
            print 'Se inserto con exito el producto';// 'Exito al insertar el producto';
        }
        else{
            print 'No se pudo insertar el producto'; //'Fallo al insertar el producto';
        }
    }
    public function borrarprod($sku){
        $db=db_connect();

        $builder = $db->table('productos');

        $respuesta=$db->query("SELECT sku FROM productos WHERE SKU=".$sku.";")->getResult();
        if (COUNT($respuesta)>=0){
            print "Se elimino el producto";
        } 
        else{
            print "No se elimino el producto";
        }

        $builder->where('SKU', $sku);
        $builder->delete();

    }

    public function actualizarprod($sku,$nombre,$descripcion,$precio){
        $db=db_connect();
        $builder = $db->table('productos');
        
        $datos = array(
            'NOMBRE' => $nombre,
            'DESCRIPCION' => $descripcion,
            'PRECIO' => $precio
        );

        $respuesta=$db->query("SELECT sku FROM productos WHERE SKU=".$sku.";")->getResult();
        if (COUNT($respuesta)>=1){
            print "Se actualizo el producto";
        } 
        else{
            print "No se actualizo el producto";
        }

        $builder->where('SKU', $sku);
        $respuesta=$builder->update($datos);

    }

public function busquedaprod(){
    //return $this->findAll();
    $db=db_connect();

    $query=$db->query("SELECT * FROM productos;")->getResult();
    return $query;
}

public function busquedaidprod($id){

    return $this->where('id',$id)->findAll();

}
}