<?php

namespace App\Models;

use CodeIgniter\Model;

class plazos_mod extends Model
{
    protected $table      = 'plazos';
    protected $primaryKey = 'ID';

    //protected $useAutoIncrement = true;

    protected $returnType     = 'array';

    protected $allowedFields = ['SEMANAS', 'TASA_PUNTUTAL', 'TASA_NORMAL', 'DESCRIPCION'];


    public function subidaplazos($semanas,$tasa_puntual,$tasa_normal,$descripcion){

        $db=db_connect();
        $builder = $db->table('plazos');
        
        $datos = array(
            'SEMANAS' => $semanas,
            'TASA_PUNTUAL' => $tasa_puntual,
            'TASA_NORMAL' => $tasa_normal,
            'DESCRIPCION' => $descripcion
        );

        $builder->insert($datos);

        if ($db->insertID()>=1){
            print 'Se registro el plazo con exito';// 'Exito al insertar el plazo';
        }
        else{
            print 'No se pudo registrar el plazo'; //'Fallo al insertar el plazo';
        }
    }
    
public function busquedaplazos(){
    return $this->findAll();
    
}

public function busquedaidplazo($id){

    return $this->where('id',$id)->findAll();

}

}