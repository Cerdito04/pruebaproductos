<?php
use App\Models\plazos_mod ;
$conex=new plazos_mod;
if($_POST['nm-btn-agregar-prod']==1){

$conex->subidaplazos($_POST['nm-SEMANAS-prod'],$_POST['nm-TPUNTUAL-prod'],$_POST['nm-TNORMAL-prod'],$_POST['nm-DESCRIPCION-prod']);

}


?>