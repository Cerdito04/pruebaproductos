<?php  namespace App\Controllers; ?>

<form method="post" action="<?php echo base_url().'/subida-plazos'?>" target="prueba-plazos">
<div class="form-group col-md-12" >
    <label for="Descripción del producto">Descripcion:</label>
    <textarea type="text" class="form-control" name="nm-DESCRIPCION-prod" rows="4" placeholder="Descripcion(opcional)..."></textarea>
  </div>

  <div class="form-group col-md-6">
    <label for="Nombre del producto">Tasa(Normal):</label>
    <input type="number" step="any" class="form-control" name="nm-TNORMAL-prod" id="id-Nombre-prod" placeholder="Tasa (Normal)..." required>
  </div>

  <div class="form-group col-md-6">
    <label for="Precio del producto">Tasa(Puntual):</label>
    <input type="number" step="any" class="form-control" name="nm-TPUNTUAL-prod" placeholder="Tasa (Puntual))...">
  </div>

  <div class="form-group col-md-4">
    <label for="SKU del producto">SEMANAS:</label>
    <input type="number" step="any" class="form-control" name="nm-SEMANAS-prod" placeholder="Semanas a pagar..." required>
  </div>

  <div class="text-center col-md-12" ><button type="submit" name="nm-btn-agregar-prod" class="btn btn-success" value="1">Agregar</button> </div>

</form>

<iframe name="prueba-plazos" style="width:100%; margin:1%;" href="<?php echo base_url().'/subida-plazos'?>"></iframe>