<?php  
namespace App\Controllers; 
use App\Models\productos_mod;
?>

<form method="post" action="">
  <div class="form-group col-md-6">
    <label for="SKU del producto">SKU:</label>
    <input type="number" class="form-control" name="nm-SKU-prod"  placeholder="SKU del producto..." disabled>
  </div>

<div class="form-group col-md-6" >
    <label for="NOMBRE del producto">NOMBRE DEL PRODUCTO:</label>
    <select class="form-control" id="id-NOMBRE-prod" name="nm-NOMBRE-prod" >
<?php 
$db=new productos_mod; 

$productos=$db->busquedaprod();

for($f=0;$f<count($productos);$f++)  
{
     echo '<option value="'.$productos[$f]->ID.'">'.$productos[$f]->NOMBRE.'</option>'; 
     
}
?>        
</select>
  </div>

  <div class="form-group col-md-6" >
    <label for="Descripción del producto">SEMANAS(Plazo)</label>
    <select class="form-control" id="id-PLAZOS-prod" name="nm-PLAZOS-prod" >
<?php 
    
    $tasas=array();
foreach ($plazos as $fila) 
{

     echo '<option value="'.$fila['ID'].'">'.$fila['SEMANAS'].'</option>'; 
     $tasas[]=$fila;
   
}

?> 

</select>
  </div>

  <div class="form-group col-md-4">
    <label for="Costo del producto">COSTO DEL PRODUCTO:</label>
    <input type="number" type="any" class="form-control" id="id-COSTO-prod" name="nm-COSTO-prod" disabled>
  </div>

</form>


<table class="table">
<tr>

<th>(PAGO SEMANAL)TASA_PUNTUAL</th>

<th>(PAGO SEMANAL)TASA_NORMAL</th>
</tr>
<tr>

<td id="id-tasapuntual"></td>

<td id="id-tasanormal"></td>
</tr>
</table>

<script> 

$(document).ready(function(){
$('#id-NOMBRE-prod,#id-PLAZOS-prod').on('change',function(){
    $('#id-COSTO-prod').val($('#id-NOMBRE-prod').val());

    obtenertasas ($('#id-NOMBRE-prod').val(),$('#id-PLAZOS-prod').val());

});

// $('#id-PLAZOS-prod').on('change',function(){
//     var costo=$('#id-COSTO-prod').val();
//     var semanas=$('#id-PLAZOS-prod option:selected').text();
//     alert(costo*semanas);
// });

});

function obtenertasas (producto,plazo){
    $.ajax({
url:"<?php echo base_url().'/calculocot'?>",
method:'POST',
dataType:'json',
data:{producto:producto, plazo:plazo},
error:function(error){
console.log(error);
},
success:function(data){
    console.log(data);
    $('#id-COSTO-prod').val(data.costo);
    $('#id-tasapuntual').text(data.calculopuntual);
    $('#id-tasanormal').text(data.calculonormal);
    
}
});
}

</script>