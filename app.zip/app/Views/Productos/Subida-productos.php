<?php
use App\Models\productos_mod ;
$conex=new productos_mod;
if($_POST['nm-btn-agregar-prod']==1){

$conex->subidaprod($_POST['nm-SKU-prod'],$_POST['nm-NOMBRE-prod'],$_POST['nm-DESCRIPCION-prod'],$_POST['nm-PRECIO-prod']);

}
elseif($_POST['nm-btn-borrar-prod']==2){
    $conex->borrarprod($_POST['nm-SKU-prod']);

}
elseif($_POST['nm-btn-actualizar-prod']==3){
    $conex->actualizarprod($_POST['nm-SKU-prod'],$_POST['nm-NOMBRE-prod'],$_POST['nm-DESCRIPCION-prod'],$_POST['nm-PRECIO-prod']);

}

?>