<?php  namespace App\Controllers; ?>
<form method="post" action="<?php echo base_url().'/Subida-productos'?>" target="prueba">
  <div class="form-group col-md-4">
    <label for="SKU del producto">SKU:</label>
    <input type="number" class="form-control" name="nm-SKU-prod"  placeholder="SKU del producto..." required>
  </div>
  <div class="form-group col-md-8">
    <label for="Nombre del producto">NOMBRE DEL PRODUCTO:</label>
    <input type="text" class="form-control" name="nm-NOMBRE-prod" id="id-Nombre-prod" placeholder="Nombre del producto..." >
  </div>
  <div class="form-group col-md-12" >
    <label for="Descripción del producto">Descripción</label>
    <textarea type="text" class="form-control" name="nm-DESCRIPCION-prod" id="id-descripcion-prod" rows="4" placeholder="Descripción del producto..." ></textarea>
  </div>
  <div class="form-group col-md-8">
    <label for="Precio del producto">PRECIO DEL PRODUCTO:</label>
    <input type="number" step="any" min="1" class="form-control" name="nm-PRECIO-prod" id="id-precio-prod" placeholder="Precio del producto..." >
  </div>
  <div class="text-center col-md-12" ><button type="submit" name="nm-btn-agregar-prod" class="btn btn-success" value="1">Agregar</button> </div>
  <div class="text-center col-md-12" ><button type="submit" name="nm-btn-borrar-prod" class="btn btn-danger" value="2">Borrar</button> </div>
  <div class="text-center col-md-12" ><button type="submit" name="nm-btn-actualizar-prod" class="btn btn-warning" value="3">Actualizar</button> </div>

</form>

<iframe name="prueba" style="width:100%; margin:1%;" href="<?php echo base_url().'/Subida-productos'?>"></iframe>