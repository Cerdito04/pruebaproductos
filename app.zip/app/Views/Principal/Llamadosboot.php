<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta http-equiv=”Content-Type” content=”text/html; charset=ISO-8859-1″ />
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<link rel="stylesheet" href="<?php echo base_url() ?>/public/Frames/Bootstrap/bootstrap.min.css"/>

<script src="<?php echo base_url() ?>/public/Frames/Jquery/jquery-3.4.1.min.js"></script> 
<script src="<?php echo base_url() ?>/public/Frames/Bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>/public/Frames/Bootstrap/popper.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>
</head>
<body>