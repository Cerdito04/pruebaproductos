<ul class="nav nav-pills">
  <!-- <li role="presentation" class="active"><a href="#">Home</a></li> -->
  <li role="presentation"><a href="<?php echo base_url()."/productos"?>">Productos</a></li>
  <li role="presentation"><a href="<?php echo base_url()."/cotizacion"?>">Cotizaciones</a></li>
  <li role="presentation"><a href="<?php echo base_url()."/plazos"?>">Plazos</a></li>
</ul>
