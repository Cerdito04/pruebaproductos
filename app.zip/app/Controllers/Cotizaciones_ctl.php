<?php

namespace App\Controllers;

use App\Models\plazos_mod;
use App\Models\productos_mod;
class Cotizaciones_ctl extends BaseController
{
    public function __construct(){
        $this->modelo_plazos = new plazos_mod();
        $this->productos = new productos_mod();
    }
    public function index()
    {
        $plazos=$this->modelo_plazos->busquedaplazos();
    
        return view('/Cabeceras/Cotizacion-cab').view('/Principal/Llamadosboot',['plazos'=>$plazos]).view('/FTHD/header').view('/Cotizaciones/Cotizacion');
    }

    public function calculo()
    {
        $plazo=$this->modelo_plazos->busquedaidplazo($_POST['plazo']);
        $prod=$this->productos->busquedaidprod($_POST['producto']);
        $calculonormal=(($plazo[0]['TASA_NORMAL']*$prod[0]['PRECIO'])+$prod[0]['PRECIO'])/$plazo[0]['SEMANAS'];
        $calculopuntual=(($plazo[0]['TASA_PUNTUAL']*$prod[0]['PRECIO'])+$prod[0]['PRECIO'])/$plazo[0]['SEMANAS'];
        // return json_encode([$_POST['producto'],$_POST['plazo'],$prod,$plazo]);
        return json_encode(['calculonormal'=>$calculonormal,'calculopuntual'=>$calculopuntual,'costo'=>$prod[0]['PRECIO']]);
    }
    
}
