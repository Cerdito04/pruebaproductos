<?php

namespace App\Controllers;

class Carga_plazos_ctl extends BaseController
{
    public function index()
    {
        return view('/Cabeceras/Carga-plazos-cab').view('/Principal/Llamadosboot').view('FTHD/header').view('/Plazos/Carga-plazos');
    }

    public function subidaplazos()
    {
        return view('/Plazos/Subida-plazos');
    }
}
