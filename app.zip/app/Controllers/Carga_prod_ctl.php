<?php

namespace App\Controllers;

class Carga_prod_ctl extends BaseController
{

    public function index()
    {
        return view('/Cabeceras/Carga-prod-cab').view('/Principal/Llamadosboot').view('FTHD/header').view('/Productos/Carga-productos');
    }

    public function subidaprod()
    {
        return view('/Productos/Subida-productos');
    }
    
}
